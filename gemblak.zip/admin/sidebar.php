   <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav mt-5 flex-column">
                            <li class="nav-divider">
                                <h3 class="text-white">ADMIN</h2>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link " href="./?page=beranda" ><i class="fa fa-fw fa-home"></i>HOME</a>
                                
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" href="./?page=masyarakat"><i class="fas fa-fw fa-chart-pie"></i>MASYARAKAT</a>
                                
                            </li>

                            <li class="nav-item ">
                                <a  class="nav-link" href="./?page=kuisioner"><i class="fab fa-fw fa-wpforms"></i>PERTAYAAN</a>

                             </li>
                            <li class="nav-item">
                                <a class="nav-link" href="./?page=hasil"><i class="fas fa-fw fa-table"></i>HASIL</a>
                                </li>
                                    <li class="nav-item">
                                <a class="nav-link" href="./?page=user"><i class="fa fa-fw fa-user-circle"></i>user</a>
                                </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>